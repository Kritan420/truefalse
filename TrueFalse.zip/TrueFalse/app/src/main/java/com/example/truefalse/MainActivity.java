package com.example.truefalse;

import androidx.appcompat.app.AppCompatActivity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView textStatement, textC, textW, textT, textS;
    private ArrayList<Statements> list;
    private Total t;
    private Correct c;
    private Wrong w;
    private RandNumber r;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // alla olika textfält
        textStatement = (TextView) findViewById(R.id.textStatement);  // fält med påståendet
        textC = (TextView) findViewById(R.id.textC); // correct
        textW = (TextView) findViewById(R.id.textW); // wrong
        textT = (TextView) findViewById(R.id.textT); // total

        // statementcount , eventuellt tar vi bort den, behövs mest internt inom programmet, överflödigt som användare
        textS = (TextView) findViewById(R.id.textS);
        // har satt textS som invisible i layout -> activity_main.xml
        // den finns kvar och uppdateras men känns inte som man behöver se den

        try {
            setStart(); // sätt igång inläsningen , nästa metod nedanför
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void setStart() throws IOException {

        list = new ArrayList<>();
        String statement;
        String answer;

        // Try läsa in alla statements från statements.txt som finns i mappen res -> raw -> statements.txt
        // Läser in hela skiten och sen skickar bufferedreadern ut dom igen rad för rad
        // i .txt är det en rad påstående, nästa rad om sant/falskt och så snurrar det

        BufferedReader reader = null;
        try {
            Resources res = getResources();
            InputStream ins = res.openRawResource(R.raw.statements);
            reader = new BufferedReader(new InputStreamReader(ins));
        } catch (Exception e) {
        e.printStackTrace();
        }

        // Condition i whileloopen ser till att stringarna statement och answer fortsätter uppdateras och matas in
        // inte sett förr
        //Sen lägga in dom i listan tills alla är inne

        try {
            while (((statement = reader.readLine()) != null) && ((answer = reader.readLine()) != null) ) {
            list.add(new Statements(statement, answer));
            }
        } catch (NullPointerException e) {
        e.printStackTrace();
        }

        // någon på nätet påstod att det är viktigt att stänga för annars kukar det ur, ej testat utan
        reader.close();

        // alla hjälpklasser för att hålla räkningen. går säkert med int istället här men behövdes när
        // man behövde räkna upp och ner inne i lambdauttrycken från originalprogrammet
        // alla dom här klasserna är på bäbisnivå så ingen förklaring behövs
        t = new Total();
        c = new Correct();
        w = new Wrong();
        r = new RandNumber(list); // arraylisten list skickas in och sen tas randomnummer fram ur dess size()

        textS.setText("Statementcount: " + list.get(r.getValue()).getCount()); //räknar hur ofta ett påstående har kommit , eventuellt ta bort
        textStatement.setText(list.get(r.getValue()).getStatement()); // ta fram random påstående från listan

        textC.setText("Rätt: " + c.getValue()); // räknar hur många rätt
        textW.setText("Fel: " + w.getValue()); // räknar hur många fel
        textT.setText("Totalt: " + t.getValue()); // räknar hur många totalt

    }


    public void tButtonClick(View v) { // truebuttonclick
        textC.setBackgroundResource(0); // om man trycker snabbare än 1000ms så att inte två färger visas samtidigt, 0 som i ingen bakgrundsfärg
        textW.setBackgroundResource(0); // fältet Correct och Wrong får bakgrundsfärg så man får indikation på om man har rätt eller inte,
                                        // dom här två återställer den färgen

        if (list.get(r.getValue()).getBool()) {  //om rätt , alla statements har en tillhörande bool true/false som skapas ur .txt-filen
            correct(); //kör correctmetoden
        } else {  // om fel
            wrong(); //kör wrongmetoden
        }
    }

    public void fButtonClick(View v) { // falsebuttonclick
        textC.setBackgroundResource(0); //ta bort bakgrundsfärger
        textW.setBackgroundResource(0);

        if (!list.get(r.getValue()).getBool()) {  //samma som ovan men omvänt
            correct();
        } else {
            wrong();
        }
    }

    public void correct() { // om du tryckte rätt
        textC.setBackgroundResource(R.color.correct);   //grön färg, inlagt under res -> values -> colors.xml
        c.increment(); // räkna upp
        textC.setText("Rätt: " + c.getValue()); // uppdatera räknare
        r.newRand(); // ny random siffra som är mellan 0 - arraylistens storlek
        String statement = list.get(r.getValue()).getStatement();  // hämta random påstående

        while (list.get(r.getValue()).getCount() > 2) {  // så inte samma påstående kommer för ofta
                                                            // vettefan vad som händer om alla har statementcount över 2
            r.newRand(); // ny random siffra som är mellan 0 - arraylistens storlek
            statement = list.get(r.getValue()).getStatement();
            textS.setText("Statementcount: " + list.get(r.getValue()).getCount()); //eventuellt ta bort
        }
        textStatement.setText(statement);  // uppdatera påstående
        textS.setText("Statementcount: " + list.get(r.getValue()).getCount()); // uppdatera hur ofta det har kommit, eventuellt ta bort

        t.increment();  //räkna upp total
        textT.setText("Totalt: " + t.getValue()); //uppdatera totalräkningen

        // nåt kaos jag hittade på internet. håller rätt-färgen grön i 1000ms innan bakgrunden återställs
        // har ingen aning vad som händer men det funkar
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                textC.setBackgroundResource(0);
            }
        }, 1000);

    }

    public void wrong() {  // nästan identisk med correct men om man trycker fel istället
                            // skillnad jämfört med correct är att man får inget nytt påstående förrän man har rätt

        textW.setBackgroundResource(R.color.wrong); //röd färg, inlagt under res -> values -> colors.xml
        w.increment(); // räkna upp antal fel
        textW.setText("Fel: " + w.getValue()); //uppdatera räkning

        t.increment(); //räkna upp total
        textT.setText("Totalt: " + t.getValue()); //uppdatera räknaare

        // nåt kaos jag hittade på internet. håller fel-färgen röd i 1000ms innan bakgrunden återställs
        // har ingen aning vad som händer men det funkar
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                textW.setBackgroundResource(0);
            }
        }, 1000);
    }

    public void rButtonClick(View v) {   // resetbuttonclick, resetta allt till 0 och ta fram nytt random påstående
        textC.setBackgroundResource(0);
        textW.setBackgroundResource(0);
        c.reset();
        w.reset();
        t.reset();
        for (int i = 0; i < list.size(); i++) {
            list.get(i).reset();
        }
        r.reset();

        textStatement.setText(list.get(r.getValue()).getStatement());
        textC.setText("Rätt: " + c.getValue());
        textW.setText("Fel: " + w.getValue());
        textT.setText("Totalt: " + t.getValue());
        textS.setText("Statementcount: " + list.get(r.getValue()).getCount());
    }
}