package com.example.truefalse;

import java.util.ArrayList;
import java.util.Random;

public class RandNumber {
    private int value;
    private int size;
    private Random rand;

    public RandNumber(ArrayList<Statements> list) {
        size = list.size();
        rand = new Random();
        value = rand.nextInt(size);

    }

    public void newRand() {
        value = rand.nextInt(size);
    }

    public int getValue() {
        return value;
    }

    void reset() {
        rand = new Random();
        value = rand.nextInt(size);
    }
}
