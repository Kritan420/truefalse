package com.example.truefalse;

public class Correct {
    private int value;

    public Correct() {
        value = 0;
    }

    void increment() {
        value++;
    }

    void reset() {
        value = 0;
    }

    public int getValue() {
        return value;
    }
}
