package com.example.truefalse;

public class Wrong {
    private int value;

    public Wrong() {
        value = 0;
    }

    void increment() {
        value++;
    }

    void reset() {
        value = 0;
    }

    public int getValue() {
        return value;
    }
}

